# machine-learning-project-walkthrough 

An implementation of a complete machine learning solution in Python on a real-world dataset. This project is meant to demonstrate 
how all the steps of a machine learning pipeline come together to solve a problem! 
